CREATE DATABASE prova_finale;

USE prova_finale;


-- Creazione della tabella Product
CREATE TABLE Product (
    Product_ID INT PRIMARY KEY,
    Name VARCHAR(255),
    Category VARCHAR(255)
);

-- Creazione della tabella Region
CREATE TABLE Region (
    Region_ID INT PRIMARY KEY,
    Name VARCHAR(255)
);

-- Creazione della tabella Sales
CREATE TABLE Sales (
    Sales_ID INT PRIMARY KEY,
    Product_ID INT,
    Region_ID INT,
    OrderDate DATE,
    Quantity INT ,
    Sales_Amount DECIMAL(10, 2),
    FOREIGN KEY (Product_ID) REFERENCES Product(Product_ID),
    FOREIGN KEY (Region_ID) REFERENCES Region(Region_ID)
);

-- POPOLAZIONE TABELLE
-- PRODUCT
INSERT INTO Product (Product_ID,Name, Category) VALUES 
('1','Set Lego', 'Puzzle'),
('2','Barbie', 'Bambole'),
('3','Hot Wheels Car', 'Veicoli'),
('4','Puzzle 1000 Pezzi', 'Puzzle'),
('5','Monopoli', 'Giochi da tavolo'),
('6','Orso peluche', 'Peluche'),
('7','Risiko', 'Giochi da tavolo'),
('8','Drone telecomandato', 'Giochi Elettronici'),
('9','Playstation', 'Hardware'),
('10','Pc preassemblato', 'Hardware');

-- REGION
INSERT INTO Region (Region_ID,Name) VALUES 
('1','North America'),
('2','South America'),
('3','Europe'),
('4','Asia'),
('5','Africa'),
('6','Australia');

-- SALES
INSERT INTO Sales (Sales_ID,Product_ID, Region_ID, OrderDate, Quantity, Sales_Amount) VALUES 
('1',1, 1, '2024-01-01',1 , 15.20),
('2',2, 2, '2024-02-01', 1, 7.99),
('3',3, 3, '2024-03-01', 1, 25.10),
('4',4, 4, '2024-04-01', 1, 12.87),
('5',5, 5, '2023-05-01', 1, 13.55),
-- ('TR6',6, 6, '2023-06-01', 15, 8.15),
('6',7, 1, '2023-07-01', 1, 17.99),
('7',8, 2, '2023-08-01', 1, 60.89),
('8',9, 3, '2023-09-01', 3, 200.00),
('9',10, 4, '2023-10-01', 3, 350.00),
('10',9, 2, '2023-09-12', 3, 200.00),
('11',9, 1, '2024-07-03', 3, 200.00),
('12',10, 3, '2023-10-21', 3, 350.00),
('13',10, 6, '2024-10-13', 3, 350.00);


-- 1)VERIFICARE CHE I CAMPI DEFINITI COME PK SIANO UNIVOCI 
SELECT 
    COUNT(*)
FROM
    product
GROUP BY Product_ID
HAVING COUNT(*) > 1;
 
SELECT 
    COUNT(*)
FROM
    region
GROUP BY Region_ID
HAVING COUNT(*) > 1; 

SELECT 
    COUNT(*)
FROM
    sales
GROUP BY Sales_ID
HAVING COUNT(*) > 1;

 
-- 2)ESPORRE L ELENCO DEI SOLI PRODOTTI VENDUTI E PER OGNUNO DI QUESTI IL FATTURATO TOTALE PER ANNO 
SELECT 
    product.Name, SUM(sales.Sales_Amount), YEAR(OrderDate)
FROM
    sales
        JOIN
    product ON sales.Product_ID = product.Product_ID
GROUP BY YEAR(OrderDate),product.Name;

-- 3)ESPORRE IL FATTURATO TOTALE PER STATO PER ANNO. ORDINA IL RISULTATO PER DATA E PER FATTURATO DECRESCENTE
SELECT 
    SUM(sales.Sales_Amount), region.Name, YEAR(OrderDate)
FROM
    sales
        JOIN
    region ON sales.Region_ID = region.Region_ID
GROUP BY region.Name , YEAR(OrderDate)
ORDER BY SUM(sales.Sales_Amount) DESC , YEAR(OrderDate) DESC;

-- 4)RISPONDERE ALLA SEGUENTE DOMANDA: QUAL E' LA CATEGORIA DI ARTICOLI MAGGIORMENTE RICHIESTA DAL MERCATO?
SELECT 
    product.category, SUM(sales.quantity) AS totale_quantita_venduta
FROM
    product
        JOIN
    sales  ON product.product_id = sales.product_id
GROUP BY product.category
ORDER BY totale_quantita_venduta DESC
LIMIT 1; -- IN QUESTO CASO LA CATEGORIA PIU RICHIESTA è HARDWARE

-- 5)RISPONDERE ALLA SEGUENTE DOMANDA: QUALI SONO , SE CI SONO, I PRODOTTI INVENDUTI? PROPONI DUE APPROCCI RISOLUTIVI DIFFERENTI.
SELECT 
    Product_ID
FROM
    product
WHERE
    Product_ID NOT IN (SELECT 
            Product_ID
        FROM
            sales);
-- SECONDO APPROCCIO NON TANTO DIVERSO
SELECT 
    Product_ID
FROM
    product
WHERE
    Product_ID = null  IN (SELECT 
            Product_ID
        FROM
            sales);
-- TERZO APPROCCIO 
SELECT 
    sales.Product_ID
FROM
    product
        LEFT JOIN
    sales ON product.Product_ID = sales.Product_ID
WHERE
    sales.Product_ID = NULL;

            
-- 6)ESPORRE L ELENCO DEI PRODOTTI CON LA RISPETTIVA ULTIMA DATA DI VENDITA(LA DATA DI VENDITA PIU RECENTE)
SELECT 
    product.Name, MAX(OrderDate)
FROM
    sales
        JOIN
    product ON sales.Product_ID = product.Product_ID
GROUP BY product.Name;












